from django.shortcuts import render
from django.template import loader
# Create your views here.
from django.http import HttpResponse
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from statsmodels.stats.outliers_influence import variance_inflation_factor
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
import matplotlib.pyplot as plt
import mpld3
import pandas as pd





def index(request):
    # Charger le fichier CSV à partir de l'URL
    df = pd.read_csv("SeoulBikeData.csv",encoding="latin1")


    # Remplacer les valeurs yes et no par 1 et 0 dans la colonne Functional Day
    df["Functioning Day"] = df["Functioning Day"].replace({"Yes": 1, "No": 0})

    df["Holiday"] = df["Holiday"].replace({"Holiday": 1, "No Holiday": 0})

    # Convertir en format date
    df["Date"] = pd.to_datetime(df["Date"], format="%d/%m/%Y")
    # Compter le nombre de lignes contenant des valeurs nulles
    nb_lignes_nulles = df.isnull().any(axis=1).sum()

    # Compter le nombre de locations pendant des jours de vacances
    nb_locations_vacances = df.groupby("Holiday")["Rented Bike Count"].sum()

    # Compter le nombre de locations pendant des jours feriés
    nb_locations_feries = df.groupby("Functioning Day")["Rented Bike Count"].sum()


    #enlever les jours feriés car aucune location ces jours là
    df = df.drop("Functioning Day", axis=1)

    # Enlever les lignes sans locations
    df = df [df ["Rented Bike Count"] != 0]
    # Ajoute des colonnes, par exemple month donne un int pour savoir à quel mois de l'année la ligne correspond
    # Cela permet d'attribuer des valeurs numériques à des labels (janvier,février...) et ainsi pouvoir entrainer les modèles
    df["weekday"] = df["Date"].dt.day_name()
    df["Day"] = df["Date"].dt.day
    df["Month"] = df["Date"].dt.month
    # Créer des variables indicatrices pour chaque jour de la semaine
    df_dummies = pd.get_dummies(df["Seasons"])

    # Fusionner les dataframes
    df = pd.concat([df, df_dummies], axis=1)

    df.drop("Date", axis=1, inplace=True)

    # Afficher le résultat
    df.info()
    # Occurence de chaque mois
    df[['Winter', 'Summer', 'Spring', 'Autumn']].sum()
    # Grouper le dataframe par jour de la semaine et calculer la somme des locations
    df_grouped = df.groupby("weekday")["Rented Bike Count"].sum()

    # Créer un graphique à barres avec matplotlib
    plt.bar(df_grouped.index, df_grouped.values)
    plt.xlabel("Jour de la semaine")
    plt.ylabel("Nombre de locations")
    plt.title("Nombre de locations par jour de la semaine")
    html_graph = mpld3.fig_to_html(plt.gcf())

    template = loader.get_template("template0.html")
    
    context = {
        'html_graph':html_graph,
        
    }
    return HttpResponse(template.render(context, request))
    #return HttpResponse("Hello, world. You're at the polls index.")